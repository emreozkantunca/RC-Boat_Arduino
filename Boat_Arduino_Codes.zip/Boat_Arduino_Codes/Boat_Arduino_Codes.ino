// C++ code
//
#include <Servo.h>  // Include the Servo library
Servo myServo;
int pot = A5;
int pot2 = A4;
int reading,num, newPos, currMap;


// Define motor control pins for Motor 1
const int motor1Pin1 = 2;  
const int motor1Pin2 = 3;  
  

// Define the servo control pin
const int servoPin = 9;    

// Define timing variables
unsigned long previousMotorMillis = 0;
unsigned long previousServoMillis = 0;
const long motorRunInterval = 5000;  // 5 seconds for motor running
const long motorStopInterval = 5000; // 5 seconds stop
const long servoInterval = 2000;     // 2 seconds for servo control
bool motorRunning = true;  // Flag to track motor state (running or stopping)
bool motorForward = true;  // Flag to track motor direction

void setup() {
   pinMode(pot, INPUT);
  myServo.attach(9);
  
  Serial.begin(9600);
  
  // Set motor pins as outputs for Motor 1, Motor 2 and second pot
  pinMode(motor1Pin1, OUTPUT);
  pinMode(motor1Pin2, OUTPUT);
  pinMode(pot2, INPUT);
  
  // Attach the servo to its control pin
  myServo.attach(servoPin);

  // Start motors in the forward direction
  digitalWrite(motor1Pin1, HIGH);
  digitalWrite(motor1Pin2, HIGH);
}

/*
 *Get the current reading from potentiometer 
 * 10-Bit: 0-1023
*/ 

int readPot(){
  int curr;
  if (curr != reading){
    reading = analogRead(pot);
    curr = reading;
  }
  return reading;
}
/*
 *Take a position and set the servo in the correct range
 */
void mapServo(int pos){
  num = map(pos, 675, 1023, 0, 180);
  myServo.write(num);
  delay(50);
}

void loop() {
   newPos = readPot();
  mapServo(newPos);
  
  if(currMap != newPos){
    Serial.println("Pot Position = ");
    Serial.print(newPos);
    Serial.println(" Servo Angle = ");
    Serial.print(num);
    currMap = newPos;
  }
  
  unsigned long currentMillis = millis();
  // Control DC motors
  if (motorRunning) {
    if (currentMillis - previousMotorMillis >= motorRunInterval) {
      previousMotorMillis = currentMillis;

      // Stop the motors for 5 seconds
      digitalWrite(motor1Pin1, LOW);
      digitalWrite(motor1Pin2, LOW);
 

      motorRunning = false;  // Motors are now stopping
    }
  } else {
    if (currentMillis - previousMotorMillis >= motorStopInterval) {
      previousMotorMillis = currentMillis;

      // After the stop, toggle motor direction
      if (motorForward) {
        // Move motors in reverse
        digitalWrite(motor1Pin1, HIGH);
        digitalWrite(motor1Pin2, HIGH);
   
        motorForward = false;
      } else {
        // Move motors forward
        digitalWrite(motor1Pin1, HIGH);
        digitalWrite(motor1Pin2, HIGH);
        motorForward = true;
      }

      motorRunning = true;  // Motors are now running again
    }
  }
}
 